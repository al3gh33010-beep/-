ALTER TABLE `bookings` ADD `orderDate` varchar(10) DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `bookings` ADD `customerPhone` varchar(32) DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `bookings` ADD `customerEmail` varchar(320) DEFAULT '' NOT NULL;