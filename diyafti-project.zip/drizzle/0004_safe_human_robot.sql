ALTER TABLE `bookings` ADD `totalAmount` decimal(12,2) DEFAULT '0.00' NOT NULL;
--> statement-breakpoint
UPDATE `bookings` SET `totalAmount` = `unitPrice`;
