import { decimal, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const bookings = mysqlTable("bookings", {
  id: int("id").autoincrement().primaryKey(),
  uid: varchar("uid", { length: 36 }).notNull().unique(),
  orderDate: varchar("orderDate", { length: 10 }).notNull().default(""),
  eventDate: varchar("eventDate", { length: 10 }).notNull(),
  eventTime: varchar("eventTime", { length: 5 }).notNull().default(""),
  eventType: varchar("eventType", { length: 120 }).notNull(),
  guestCount: int("guestCount").notNull(),
  unitPrice: decimal("unitPrice", { precision: 12, scale: 2 }).notNull().default("0.00"),
  totalAmount: decimal("totalAmount", { precision: 12, scale: 2 }).notNull().default("0.00"),
  paidAmount: decimal("paidAmount", { precision: 12, scale: 2 }).notNull().default("0.00"),
  customerName: varchar("customerName", { length: 160 }).notNull().default(""),
  customerPhone: varchar("customerPhone", { length: 32 }).notNull().default(""),
  customerEmail: varchar("customerEmail", { length: 320 }).notNull().default(""),
  notes: text("notes"),
  status: mysqlEnum("status", ["مؤكدة", "قيد التجهيز", "مكتملة", "ملغاة"]).default("مؤكدة").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  reminderSentAt: timestamp("reminderSentAt"),
  createdEmailSentAt: timestamp("createdEmailSentAt"),
});

export const emailSettings = mysqlTable("emailSettings", {
  id: int("id").primaryKey().default(1),
  senderEmail: varchar("senderEmail", { length: 320 }).notNull().default(""),
  recipientEmail: varchar("recipientEmail", { length: 320 }).notNull().default(""),
  scheduleTaskUid: varchar("scheduleTaskUid", { length: 128 }).notNull().default(""),
  automationEnabled: int("automationEnabled").notNull().default(0),
  lastWeeklyBackupDate: varchar("lastWeeklyBackupDate", { length: 10 }).notNull().default(""),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Booking = typeof bookings.$inferSelect;
