CREATE TABLE `emailSettings` (
	`id` int NOT NULL DEFAULT 1,
	`senderEmail` varchar(320) NOT NULL DEFAULT '',
	`recipientEmail` varchar(320) NOT NULL DEFAULT '',
	`scheduleTaskUid` varchar(128) NOT NULL DEFAULT '',
	`automationEnabled` int NOT NULL DEFAULT 0,
	`lastWeeklyBackupDate` varchar(10) NOT NULL DEFAULT '',
	CONSTRAINT `emailSettings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `bookings` ADD `reminderSentAt` timestamp;