ALTER TABLE `bookings` ADD `createdEmailSentAt` timestamp;
--> statement-breakpoint
UPDATE `bookings` SET `createdEmailSentAt` = CURRENT_TIMESTAMP WHERE `createdEmailSentAt` IS NULL;
