CREATE TABLE `bookings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`uid` varchar(36) NOT NULL,
	`eventDate` varchar(10) NOT NULL,
	`eventTime` varchar(5) NOT NULL DEFAULT '',
	`eventType` varchar(120) NOT NULL,
	`guestCount` int NOT NULL,
	`customerName` varchar(160) NOT NULL DEFAULT '',
	`notes` text,
	`status` enum('مؤكدة','قيد التجهيز','مكتملة','ملغاة') NOT NULL DEFAULT 'مؤكدة',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `bookings_id` PRIMARY KEY(`id`),
	CONSTRAINT `bookings_uid_unique` UNIQUE(`uid`)
);
