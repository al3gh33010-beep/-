ALTER TABLE `bookings` ADD `unitPrice` decimal(12,2) DEFAULT '0.00' NOT NULL;--> statement-breakpoint
ALTER TABLE `bookings` ADD `paidAmount` decimal(12,2) DEFAULT '0.00' NOT NULL;