import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { Banknote, Bell, CalendarDays, Check, CheckCircle2, ChevronDown, Clock3, Download, Edit3, FileUp, LogOut, Mail, Plus, Receipt, Search, ShieldCheck, Trash2, Users, UtensilsCrossed, Phone, Wallet, X } from "lucide-react";

type Booking = { id: number; uid: string; orderDate: string; eventDate: string; eventTime: string; eventType: string; guestCount: number; totalAmount: string; paidAmount: string; customerName: string; customerPhone: string; notes: string | null; status: "مؤكدة" | "قيد التجهيز" | "مكتملة" | "ملغاة"; createdAt?: string };
type FormValues = Omit<Booking, "id" | "uid" | "createdAt" | "orderDate" | "guestCount"> & { guestCount: number | "" };
type EmailSettings = { recipientEmail: string; senderEmailConfigured: boolean; appPasswordConfigured: boolean; automationEnabled: boolean; canSchedule: boolean };
const todayISO = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`; };
const fmtDate = (value: string) => new Date(`${value}T12:00:00`).toLocaleDateString("ar-SA-u-ca-gregory", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
const asciiDigits = (value: string) => value.replace(/[٠-٩۰-۹]/g, digit => String.fromCharCode(48 + (digit.charCodeAt(0) >= 0x06f0 ? digit.charCodeAt(0) - 0x06f0 : digit.charCodeAt(0) - 0x0660)));
const normalizeMoneyInput = (value: string) => { const text = asciiDigits(value).replace(/٫/g, ".").replace(/[٬,\s]/g, "").replace(/[^\d.]/g, ""); const [whole, ...fraction] = text.split("."); return fraction.length ? `${whole}.${fraction.join("").slice(0, 2)}` : whole; };
const moneyCents = (value: string | number | null | undefined) => { if (value == null || value === "") return 0; const text = asciiDigits(String(value)).replace(/٫/g, ".").replace(/[٬,\s]/g, ""); if (!/^\d{1,9}(?:\.\d{1,2})?$/.test(text)) return Number.NaN; const cents = Math.round((Number(text) + Number.EPSILON) * 100); return Number.isSafeInteger(cents) && cents <= 10_000_000_000 ? cents : Number.NaN; };
const formatSAR = (cents: number) => new Intl.NumberFormat("ar-SA", { style: "currency", currency: "SAR", minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(cents / 100);
const bookingTotalCents = (booking: Booking) => moneyCents(booking.totalAmount);
const invoiceNumber = (b: Booking) => `LART-${(b.orderDate || b.eventDate).slice(0, 4)}-${String(b.id).padStart(6, "0")}`;
const SESSION_TOKEN_KEY = "diyafti-session-token";
let inMemorySessionToken: string | null = null;
function getSessionToken() { try { return window.sessionStorage.getItem(SESSION_TOKEN_KEY) || inMemorySessionToken; } catch { return inMemorySessionToken; } }
function storeSessionToken(token: string) { inMemorySessionToken = token; try { window.sessionStorage.setItem(SESSION_TOKEN_KEY, token); } catch { /* Keep the bearer in memory for this page session. */ } }
function clearSessionToken() { inMemorySessionToken = null; try { window.sessionStorage.removeItem(SESSION_TOKEN_KEY); } catch { /* Ignore unavailable storage. */ } }
const defaultForm = (): FormValues => ({ eventDate: todayISO(), eventTime: "", eventType: "", guestCount: "", totalAmount: "", paidAmount: "", customerName: "", customerPhone: "", notes: "", status: "مؤكدة" });
async function api<T>(path: string, options: RequestInit = {}): Promise<T> {
  const headers = new Headers(options.headers); headers.set("Content-Type", "application/json");
  const token = getSessionToken(); if (token) headers.set("Authorization", `Bearer ${token}`);
  const response = await fetch(`/api/private${path}`, { ...options, credentials: "same-origin", headers });
  const body = await response.json().catch(() => ({}));
  if (response.status === 401 && path !== "/login") { clearSessionToken(); window.dispatchEvent(new Event("diyafti-session-expired")); }
  if (!response.ok) throw new Error(body.error || "تعذر إكمال الطلب.");
  return body as T;
}

export default function Home() {
  const [authenticated, setAuthenticated] = useState(false);
  const [checking, setChecking] = useState(true);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(false);
  const [loginError, setLoginError] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("الكل");
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<Booking | null>(null);
  const [form, setForm] = useState<FormValues>(defaultForm());
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState("");
  const [message, setMessage] = useState("");
  const [invoiceBooking, setInvoiceBooking] = useState<Booking | null>(null);
  const [notifyPermission, setNotifyPermission] = useState(typeof Notification === "undefined" ? "unsupported" : Notification.permission);
  const backupInput = useRef<HTMLInputElement>(null);
  const [emailSettings, setEmailSettings] = useState<EmailSettings | null>(null);
  const [recipientEmail, setRecipientEmail] = useState("");
  const [emailError, setEmailError] = useState("");
  const [emailBusy, setEmailBusy] = useState(false);

  async function loadBookings() {
    setLoading(true);
    try { const data = await api<Booking[]>("/bookings"); setBookings(data); }
    catch (e) { setMessage(e instanceof Error ? e.message : "تعذر تحميل البيانات."); }
    finally { setLoading(false); }
  }
  async function loadEmailSettings() {
    try { const data = await api<EmailSettings>("/email-settings"); setEmailSettings(data); setRecipientEmail(data.recipientEmail); setEmailError(""); }
    catch (e) { setEmailError(e instanceof Error ? e.message : "تعذر تحميل إعدادات Gmail."); }
  }
  useEffect(() => { api<{authenticated:boolean}>("/me").then(async v => { setAuthenticated(v.authenticated); if (v.authenticated) await loadBookings(); }).catch(() => {}).finally(() => setChecking(false)); }, []);
  useEffect(() => { if (authenticated) void loadEmailSettings(); else { setEmailSettings(null); setRecipientEmail(""); } }, [authenticated]);
  useEffect(() => { const onExpired = () => { setAuthenticated(false); setBookings([]); setUsername(""); setPassword(""); setLoginError("انتهت الجلسة، سجّل الدخول مرة أخرى."); }; window.addEventListener("diyafti-session-expired", onExpired); return () => window.removeEventListener("diyafti-session-expired", onExpired); }, []);

  const upcoming = useMemo(() => {
    const today = todayISO(); const edgeDate = new Date(); edgeDate.setDate(edgeDate.getDate() + 7);
    const edge = `${edgeDate.getFullYear()}-${String(edgeDate.getMonth()+1).padStart(2,"0")}-${String(edgeDate.getDate()).padStart(2,"0")}`;
    return bookings.filter(b => b.eventDate >= today && b.eventDate <= edge && b.status !== "مكتملة" && b.status !== "ملغاة");
  }, [bookings]);
  useEffect(() => {
    if (!authenticated || notifyPermission !== "granted" || upcoming.length === 0 || typeof Notification === "undefined") return;
    const key = `diyafti-reminder-${todayISO()}`;
    if (localStorage.getItem(key)) return;
    new Notification("تذكير ضيافتي", { body: `عندك ${upcoming.length} موعد خلال الأيام السبعة القادمة.` });
    localStorage.setItem(key, "shown");
  }, [authenticated, notifyPermission, upcoming]);
  const visible = useMemo(() => bookings.filter(b => {
    const match = `${b.eventType} ${b.customerName} ${b.customerPhone} ${b.notes || ""}`.toLowerCase().includes(query.toLowerCase());
    return match && (filter === "الكل" || b.status === filter);
  }), [bookings, query, filter]);
  const thisMonthCount = bookings.filter(b => b.eventDate.slice(0,7) === todayISO().slice(0,7) && b.status !== "ملغاة").length;
  const formTotalCents = form.totalAmount === "" ? null : moneyCents(form.totalAmount);
  const formPaidCents = moneyCents(form.paidAmount);
  const formRemainingCents = formTotalCents === null || !Number.isSafeInteger(formTotalCents) || !Number.isSafeInteger(formPaidCents) ? null : formTotalCents - formPaidCents;

  async function login(e: FormEvent) {
    e.preventDefault(); setLoginError("");
    try { const session = await api<{token?:string}>("/login", { method: "POST", body: JSON.stringify({ username, password }) }); if (session.token) storeSessionToken(session.token); setUsername(""); setPassword(""); setAuthenticated(true); await loadBookings(); }
    catch (error) { setLoginError(error instanceof Error ? error.message : "تعذر تسجيل الدخول."); }
  }
  async function logout() { await api("/logout", { method: "POST" }).catch(() => {}); clearSessionToken(); setUsername(""); setPassword(""); setAuthenticated(false); setBookings([]); }
  function openAdd() { setEditing(null); setForm(defaultForm()); setFormError(""); setModal(true); }
  function openEdit(b: Booking) { setEditing(b); setForm({ eventDate: b.eventDate, eventTime: b.eventTime || "", eventType: b.eventType, guestCount: b.guestCount, totalAmount: b.totalAmount || "0.00", paidAmount: b.paidAmount || "0.00", customerName: b.customerName || "", customerPhone: b.customerPhone || "", notes: b.notes || "", status: b.status }); setFormError(""); setModal(true); }
  async function saveBooking(e: FormEvent) {
    e.preventDefault(); setFormError("");
    if (form.guestCount === "" || form.guestCount < 1 || form.guestCount > 100000) { setFormError("اكتب عدد الأشخاص (من 1 إلى 100000) قبل الحفظ."); return; }
    const totalAmountCents = moneyCents(form.totalAmount); const paidAmountCents = moneyCents(form.paidAmount);
    if (!Number.isSafeInteger(totalAmountCents) || !Number.isSafeInteger(paidAmountCents)) { setFormError("تحقق من الإجمالي والمدفوع؛ اكتب مبلغًا صحيحًا وبحد أقصى منزلتين عشريتين."); return; }
    if (paidAmountCents > totalAmountCents) { setFormError("المبلغ المدفوع أكبر من إجمالي الضيافة."); return; }
    setSaving(true);
    try {
      const saved = await api<{ reminderDue?: boolean; reminderSent?: boolean; createdEmailSent?: boolean }>(editing ? `/bookings/${editing.uid}` : "/bookings", { method: editing ? "PUT" : "POST", body: JSON.stringify(editing ? form : { ...form, orderDate: todayISO() }) });
      setModal(false);
      setMessage(editing ? (saved.reminderSent ? "تم تحديث الضيافة وإرسال تذكير Gmail." : saved.reminderDue ? "تم تحديث الضيافة؛ تعذر إرسال تذكير Gmail الآن." : "تم تحديث الضيافة.") : saved.createdEmailSent ? "تمت إضافة الضيافة وإرسال تفاصيلها إلى بريد التنبيهات." : "تم حفظ الضيافة، لكن لم تُرسل تفاصيلها بالبريد. تأكدي من إعداد Gmail وبريد الاستقبال.");
      await loadBookings();
    } catch (error) { setFormError(error instanceof Error ? error.message : "تعذر حفظ الضيافة. حاول مرة أخرى."); }
    finally { setSaving(false); }
  }
  async function removeBooking(b: Booking) {
    if (!window.confirm(`هل تريد حذف ضيافة «${b.eventType}» للعميل «${b.customerName || "بدون اسم"}»؟ لن تظهر فاتورتها بعد الحذف، ولا يمكن التراجع.`)) return;
    try { await api(`/bookings/${b.uid}`, { method: "DELETE" }); setMessage("تم حذف الضيافة."); await loadBookings(); }
    catch (error) { setMessage(error instanceof Error ? error.message : "تعذر الحذف."); }
  }
  async function completeBooking(b: Booking) {
    try {
      await api(`/bookings/${b.uid}`, { method: "PUT", body: JSON.stringify({ eventDate: b.eventDate, eventTime: b.eventTime || "", eventType: b.eventType, guestCount: b.guestCount, totalAmount: b.totalAmount || "0.00", paidAmount: b.paidAmount || "0.00", customerName: b.customerName || "", customerPhone: b.customerPhone || "", notes: b.notes || "", status: "مكتملة" }) });
      setFilter("مكتملة"); setMessage("تم إكمال العمل ونقلت الضيافة إلى قائمة المكتملة."); await loadBookings();
    } catch (error) { setMessage(error instanceof Error ? error.message : "تعذر تحديث حالة الضيافة."); }
  }
  function downloadBackup() {
    const payload = { app: "ضيافتي", version: 1, exportedAt: new Date().toISOString(), bookings };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob); const link = document.createElement("a"); link.href = url; link.download = `diyafti-backup-${todayISO()}.json`; link.click(); URL.revokeObjectURL(url);
    setMessage("تم تنزيل نسخة احتياطية على جهازك.");
  }
  async function restoreBackup(file?: File) {
    if (!file) return;
    try {
      const parsed = JSON.parse(await file.text());
      if (!Array.isArray(parsed.bookings)) throw new Error("الملف لا يحتوي قائمة ضيافات صالحة.");
      if (!window.confirm(`سيتم دمج ${parsed.bookings.length} ضيافة من النسخة مع البيانات الحالية. لن تُحذف أي ضيافة. هل تتابع؟`)) return;
      const result = await api<{ imported: number }>("/bookings/import", { method: "POST", body: JSON.stringify({ bookings: parsed.bookings }) });
      setMessage(`اكتملت الاستعادة الآمنة: تمت معالجة ${result.imported} ضيافة.`); await loadBookings();
    } catch (error) { setMessage(error instanceof Error ? error.message : "تعذرت استعادة النسخة."); }
    finally { if (backupInput.current) backupInput.current.value = ""; }
  }
  async function enableNotifications() {
    if (typeof Notification === "undefined") { setMessage("إشعارات المتصفح غير مدعومة في هذا الجهاز."); return; }
    const permission = await Notification.requestPermission(); setNotifyPermission(permission);
    if (permission === "granted") setMessage("تم تفعيل إذن إشعارات المتصفح. تظهر التذكيرات عند فتح اللوحة.");
  }
  async function saveEmailSettings() {
    setEmailBusy(true); setEmailError("");
    try {
      const saved = await api<EmailSettings>("/email-settings", { method: "PUT", body: JSON.stringify({ recipientEmail }) });
      setEmailSettings(saved); setRecipientEmail(saved.recipientEmail); setMessage("تم حفظ بريد استقبال التنبيهات.");
      return true;
    } catch (error) { setEmailError(error instanceof Error ? error.message : "تعذر حفظ البريد."); return false; }
    finally { setEmailBusy(false); }
  }
  async function sendEmailTest() {
    if (!await saveEmailSettings()) return;
    setEmailBusy(true); setEmailError("");
    try { await api("/email-settings/test", { method: "POST", body: JSON.stringify({}) }); setMessage("تم إرسال رسالة اختبار إلى بريد التنبيهات."); }
    catch (error) { setEmailError(error instanceof Error ? error.message : "تعذر إرسال رسالة الاختبار."); }
    finally { setEmailBusy(false); }
  }
  async function toggleEmailAutomation() {
    if (!await saveEmailSettings()) return;
    const enabled = !emailSettings?.automationEnabled; setEmailBusy(true); setEmailError("");
    try {
      await api("/email-settings/automation", { method: "POST", body: JSON.stringify({ enabled }) });
      await loadEmailSettings(); setMessage(enabled ? "تم تفعيل التذكيرات اليومية والنسخة الأسبوعية." : "تم إيقاف التذكيرات والنسخة الأسبوعية.");
    } catch (error) { setEmailError(error instanceof Error ? error.message : "تعذر تغيير حالة الجدولة."); }
    finally { setEmailBusy(false); }
  }

  if (checking) return <div className="loading-screen"><span className="spinner"/><span>ضيافتي</span></div>;
  if (!authenticated) return <main className="login-page" dir="rtl">
    <div className="login-art"><div className="login-wordmark">ضيافتي</div><p>كل موعد له مكانه.</p></div>
    <form className="login-card" onSubmit={login}>
      <span className="eyebrow">مساحة خاصة بمشروعك</span><h1>تسجيل الدخول</h1><p className="muted">ادخل بياناتك لعرض وتنظيم مواعيد الضيافات.</p>
      <label>اسم المستخدم<input value={username} onChange={e => setUsername(e.target.value)} autoComplete="username" required /></label>
      <label>كلمة المرور<input type="password" value={password} onChange={e => setPassword(e.target.value)} autoComplete="current-password" required /></label>
      {loginError && <div className="error-box" role="alert">{loginError}</div>}
      <button className="primary-btn full" disabled={!password}>دخول آمن <span>←</span></button>
      <div className="login-security"><ShieldCheck size={16}/> محمية بجلسة خاصة ومحاولات دخول محدودة</div>
    </form>
  </main>;

  return <div className="app-shell" dir="rtl">
    <aside className="sidebar">
      <div className="brand-image"><span>ضيافتي</span></div>
      <div className="brand-caption"><span className="brand-dot"/> لوحة تنظيم الضيافات</div>
      <div className="side-rule"/><p className="side-label">القائمة الرئيسية</p>
      <a className="nav-item active" href="#dashboard"><CalendarDays size={18}/> نظرة عامة</a>
      <a className="nav-item" href="#bookings"><UtensilsCrossed size={18}/> كل الضيافات <span className="nav-count">{bookings.length}</span></a>
      <a className="nav-item" href="#backup"><ShieldCheck size={18}/> النسخ الاحتياطي</a>
      <a className="nav-item" href="#settings"><Mail size={18}/> إعدادات البريد</a>
      <div className="sidebar-spacer"/>
      <div className="side-note"><span className="mini-icon"><Bell size={15}/></span><strong>تذكيرك قريب</strong><p>تابع مواعيد الأسبوع من هنا حتى تكون كل ضيافة في وقتها.</p></div>
      <button className="logout-btn" onClick={logout}><LogOut size={17}/> تسجيل الخروج</button>
    </aside>

    <main className="main-area" id="dashboard">
      <header className="topbar"><div className="breadcrumb">ضيافتي <span>/</span> <b>نظرة عامة</b></div><div className="top-actions"><span className="today-label"><CalendarDays size={16}/>{new Date().toLocaleDateString("ar-SA-u-ca-gregory", {day:"numeric",month:"long",year:"numeric"})}</span><button className="icon-btn" aria-label="تفعيل الإشعارات" onClick={enableNotifications}><Bell size={18}/>{notifyPermission === "granted" && <i/>}</button><button className="avatar" title="الحساب">ل</button></div></header>
      <section className="content-wrap">
        <div className="page-heading"><div><span className="eyebrow">مساحة عملك</span><h1>أهلًا بك في ضيافتي</h1><p>خلّ مواعيد الضيافات مرتبة وواضحة من بدري.</p></div><button className="primary-btn" onClick={openAdd}><Plus size={18}/> إضافة ضيافة جديدة</button></div>
        {message && <div className="toast-message" role="status">{message}<button onClick={() => setMessage("")} aria-label="إغلاق"><X size={16}/></button></div>}
        <div className="stats-row">
          <article className="stat-card"><div className="stat-icon warm"><CalendarDays size={19}/></div><span>إجمالي الضيافات</span><strong>{bookings.length}</strong><small>كل المواعيد المسجلة</small></article>
          <article className="stat-card"><div className="stat-icon dark"><Clock3 size={19}/></div><span>خلال ٧ أيام</span><strong>{upcoming.length}</strong><small>{upcoming.length ? "تحتاج متابعة قريبة" : "ما فيه مواعيد قريبة حاليًا"}</small></article>
          <article className="stat-card"><div className="stat-icon sand"><Users size={19}/></div><span>ضيافات هذا الشهر</span><strong>{thisMonthCount}</strong><small>حسب تاريخ الموعد</small></article>
        </div>

        <div className="section-title" id="bookings"><div><span className="eyebrow">ترتيب المواعيد</span><h2>الضيافات القادمة</h2></div><button className="text-btn" onClick={openAdd}><Plus size={16}/> أضف موعدًا</button></div>
        {upcoming.length > 0 && <div className="reminder-banner"><div className="banner-bell"><Bell size={19}/></div><div><strong>تذكير الأسبوع</strong><p>عندك {upcoming.length} {upcoming.length === 1 ? "ضيافة" : "ضيافات"} خلال الأيام السبعة القادمة. راجع التفاصيل وجهّز طلباتك.</p></div><span className="banner-count">{upcoming.length}</span></div>}
        <section className="list-card">
          <div className="list-toolbar"><div className="search-wrap"><Search size={17}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="ابحث بالصنف أو الاسم أو بيانات التواصل"/></div><label className="filter-wrap"><span>الحالة</span><select value={filter} onChange={e => setFilter(e.target.value)}><option>الكل</option><option>مؤكدة</option><option>قيد التجهيز</option><option>مكتملة</option><option>ملغاة</option></select><ChevronDown size={14}/></label></div>
          <div className="booking-list">
            {loading ? <div className="empty-state"><span className="spinner"/> جارٍ تحميل الضيافات…</div> : visible.length === 0 ? <div className="empty-state"><div className="empty-mark"><CalendarDays size={24}/></div><strong>{bookings.length ? "ما لقينا نتيجة مطابقة" : "ابدأ بإضافة أول ضيافة"}</strong><p>{bookings.length ? "غيّر كلمة البحث أو فلتر الحالة." : "سجّل الموعد والتفاصيل، ونرتبها لك هنا."}</p>{!bookings.length && <button className="primary-btn small" onClick={openAdd}><Plus size={16}/> إضافة ضيافة</button>}</div> : visible.map(b => <article className={`booking-row ${b.status === "ملغاة" ? "is-cancelled" : ""}`} key={b.uid}>
              <div className="date-tile"><b>{new Date(`${b.eventDate}T12:00:00`).toLocaleDateString("ar-SA-u-ca-gregory",{day:"numeric"})}</b><span>{new Date(`${b.eventDate}T12:00:00`).toLocaleDateString("ar-SA-u-ca-gregory",{month:"short"})}</span></div>
              <div className="booking-main"><div className="booking-title"><h3>{b.eventType}</h3><span className={`status-chip ${b.status === "مكتملة" ? "done" : b.status === "ملغاة" ? "cancelled" : b.status === "قيد التجهيز" ? "prep" : "confirmed"}`}><i/>{b.status}</span></div><div className="booking-meta"><span><CalendarDays size={14}/>تاريخ العمل: {fmtDate(b.eventDate)}</span><span><CalendarDays size={14}/>أُضيف: {fmtDate(b.orderDate || b.eventDate)}</span>{b.eventTime && <span className="time-meta"><Clock3 size={14}/>{b.eventTime}</span>}<span><Users size={14}/>{b.guestCount} شخص</span><span><Banknote size={14}/>الإجمالي: {formatSAR(bookingTotalCents(b))}</span><span><Banknote size={14}/>المدفوع: {formatSAR(moneyCents(b.paidAmount))}</span><span><Wallet size={14}/>المتبقي: {formatSAR(bookingTotalCents(b) - moneyCents(b.paidAmount))}</span>{b.customerName && <span>{b.customerName}</span>}{b.customerPhone && <span><Phone size={13}/>{b.customerPhone}</span>}</div>{b.notes && <p className="booking-note">{b.notes}</p>}</div>
              <div className="row-actions"><button className="invoice-action" title="عرض الفاتورة" aria-label={`فاتورة ${b.customerName || b.eventType}`} onClick={() => setInvoiceBooking(b)}><Receipt size={16}/></button>{b.status !== "مكتملة" && b.status !== "ملغاة" && <button className="complete-action" title="تم إكمال العمل" aria-label={`تم إكمال العمل: ${b.eventType}`} onClick={() => completeBooking(b)}><CheckCircle2 size={15}/><span>تم إكمال العمل</span></button>}<button title="تعديل" aria-label="تعديل" onClick={() => openEdit(b)}><Edit3 size={16}/></button><button className="delete-action" title="حذف الضيافة" aria-label={`حذف ضيافة ${b.eventType}`} onClick={() => removeBooking(b)}><Trash2 size={16}/><span>حذف</span></button></div>
            </article>)}
          </div>
          <div className="list-footer"><span>عرض {visible.length} من {bookings.length} ضيافة</span><button className="text-btn" onClick={loadBookings}>تحديث القائمة</button></div>
        </section>

        <section className="backup-section" id="backup"><div className="backup-copy"><div className="stat-icon dark"><ShieldCheck size={19}/></div><div><span className="eyebrow">راحة بال أكثر</span><h2>نسخة احتياطية لبياناتك</h2><p>نزّل ملف JSON واحفظه في مكان آمن؛ يحتوي الملف على بيانات الضيافة ورقم الجوال. الاستعادة تدمج البيانات دون حذف الموجود.</p></div></div><div className="backup-actions"><button className="outline-btn" onClick={() => backupInput.current?.click()}><FileUp size={17}/> استعادة نسخة</button><button className="primary-btn" onClick={downloadBackup}><Download size={17}/> تنزيل نسخة الآن</button><input ref={backupInput} type="file" accept="application/json,.json" hidden onChange={e => restoreBackup(e.target.files?.[0])}/></div></section>
        <section className="email-settings-section" id="settings">
          <div className="section-title"><div><span className="eyebrow">إعدادات التنبيهات</span><h2>ربط Gmail</h2></div></div>
          <div className="email-settings-card">
            <div className="email-settings-head">
              <div><strong>بريد استقبال التحديثات</strong><p>عنوان Gmail المرسل ومفتاح التطبيق محفوظان بشكل آمن في الخادم. أدخلي فقط البريد الذي يستقبل التذكيرات والنسخة الأسبوعية.</p></div>
              <span className={`mail-status ${emailSettings?.senderEmailConfigured && emailSettings?.appPasswordConfigured ? "ready" : "pending"}`}>{emailSettings?.senderEmailConfigured && emailSettings?.appPasswordConfigured ? "حساب Gmail محفوظ بأمان" : "إعداد حساب Gmail غير مكتمل"}</span>
            </div>
            {emailError && <div className="error-box" role="alert">{emailError}</div>}
            <div className="email-settings-fields">
              <label className="field">البريد الذي يستقبل التنبيهات<input type="email" autoComplete="email" placeholder="you@example.com" value={recipientEmail} onChange={e => setRecipientEmail(e.target.value)} required maxLength={320}/></label>
            </div>
            <div className="gmail-security-note"><p>عنوان الإرسال ومفتاح التطبيق لا يظهران في الموقع؛ الموقع يطلب بريد الاستقبال فقط. لا تكتبي كلمة مرور حساب Google العادية أو رمز التحقق.</p><a href="https://myaccount.google.com/apppasswords" target="_blank" rel="noreferrer">إدارة كلمات مرور تطبيق Google</a></div>
            <div className="mail-schedule-state"><strong>{emailSettings?.automationEnabled ? "التذكيرات والنسخة الأسبوعية مفعّلة" : "التذكيرات والنسخة الأسبوعية متوقفة"}</strong>{!emailSettings?.canSchedule && <p>تفعيل الجدولة يتطلب نشر الموقع أولًا؛ المعاينة لا تشغّل المهام المجدولة.</p>}</div>
            <div className="email-settings-actions"><button className="outline-btn" onClick={saveEmailSettings} disabled={emailBusy}><Check size={16}/> حفظ بريد التنبيهات</button><button className="outline-btn" onClick={sendEmailTest} disabled={emailBusy || !emailSettings?.appPasswordConfigured || !emailSettings?.senderEmailConfigured || !recipientEmail.trim()}><Mail size={16}/> إرسال رسالة اختبار</button><button className="primary-btn" onClick={toggleEmailAutomation} disabled={emailBusy || !emailSettings?.appPasswordConfigured || !emailSettings?.senderEmailConfigured || !recipientEmail.trim() || !emailSettings?.canSchedule}>{emailSettings?.automationEnabled ? "إيقاف التذكيرات والنسخة" : "تفعيل التذكيرات والنسخة"}</button></div>
          </div>
        </section>
        <footer className="footer-note"><ShieldCheck size={15}/> سجلاتك محفوظة في قاعدة بيانات دائمة، وما تنحذف تلقائيًا عند الاشتباه بأي محاولة دخول.</footer>
      </section>
    </main>

    {modal && <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) setModal(false); }}><section className="booking-modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><header><div><span className="eyebrow">تفاصيل الموعد</span><h2 id="modal-title">{editing ? "تعديل الضيافة" : "إضافة ضيافة جديدة"}</h2></div><button className="close-btn" onClick={() => setModal(false)} aria-label="إغلاق"><X size={20}/></button></header>{formError && <div className="error-box" role="alert">{formError}</div>}<form onSubmit={saveBooking}>
      <label className="field full-field">الصنف أو نوع الضيافة<input autoFocus required maxLength={120} placeholder="مثال: قهوة وحلى، بوفيه عشاء…" value={form.eventType} onChange={e => setForm({...form,eventType:e.target.value})}/></label>
      <div className="field-grid"><label className="field">تاريخ العمل<input type="date" required value={form.eventDate} onChange={e => setForm({...form,eventDate:e.target.value})}/></label><label className="field">الوقت <span className="optional">اختياري</span><input type="time" value={form.eventTime} onChange={e => setForm({...form,eventTime:e.target.value})}/></label><label className="field">عدد الأشخاص<input type="text" inputMode="numeric" pattern="[0-9]*" maxLength={6} placeholder="أدخل العدد" value={form.guestCount} onChange={e => { const digits = asciiDigits(e.target.value).replace(/\D/g, ""); setForm({...form,guestCount:digits === "" ? "" : Number(digits)}); }}/></label><label className="field">اسم العميل <span className="optional">اختياري</span><input maxLength={160} placeholder="الاسم أو الجهة" value={form.customerName} onChange={e => setForm({...form,customerName:e.target.value})}/></label><label className="field">رقم جوال العميل <span className="optional">اختياري</span><input type="tel" inputMode="tel" maxLength={32} placeholder="05xxxxxxxx" value={form.customerPhone} onChange={e => setForm({...form,customerPhone:asciiDigits(e.target.value)})}/></label></div>
      <div className="money-grid">
        <label className="field">المبلغ الإجمالي للضيافة (ر.س)<input type="text" inputMode="decimal" maxLength={12} placeholder="0.00" value={form.totalAmount} onChange={e => setForm({...form,totalAmount:normalizeMoneyInput(e.target.value)})}/></label>
        <label className="field">المبلغ المدفوع (ر.س)<input type="text" inputMode="decimal" maxLength={12} placeholder="0.00" value={form.paidAmount} onChange={e => setForm({...form,paidAmount:normalizeMoneyInput(e.target.value)})}/></label>
        <div className={`money-readout ${formRemainingCents !== null && formRemainingCents < 0 ? "money-invalid" : ""}`}><span>المبلغ المتبقي</span><strong>{formRemainingCents === null ? "—" : formatSAR(formRemainingCents)}</strong></div>
        <p className="money-hint">المتبقي = المبلغ الإجمالي − المبلغ المدفوع.</p>
      </div>
      <label className="field full-field">ملاحظات إضافية<textarea rows={3} maxLength={5000} placeholder="أي تفاصيل تساعدك في التجهيز…" value={form.notes || ""} onChange={e => setForm({...form,notes:e.target.value})}/></label>
      <label className="field full-field">حالة الضيافة<select value={form.status} onChange={e => setForm({...form,status:e.target.value as FormValues["status"]})}><option>مؤكدة</option><option>قيد التجهيز</option><option>مكتملة</option><option>ملغاة</option></select></label>
      <div className="modal-actions"><button className="outline-btn" type="button" onClick={() => setModal(false)}>إلغاء</button><button className="primary-btn" type="submit" disabled={saving}>{saving ? "جارٍ الحفظ…" : <><Check size={17}/>{editing ? "حفظ التعديلات" : "حفظ الضيافة"}</>}</button></div>
    </form></section></div>}
    {invoiceBooking && <div className="modal-backdrop invoice-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) setInvoiceBooking(null); }}><section className="invoice-dialog" role="dialog" aria-modal="true" aria-label="فاتورة الضيافة"><div className="invoice-actions"><button className="outline-btn" onClick={() => setInvoiceBooking(null)}>إغلاق</button><button className="primary-btn" onClick={() => window.print()}><Receipt size={17}/> طباعة / حفظ PDF</button></div><article className="invoice-sheet" dir="rtl">
          <header className="invoice-header">
            <div className="invoice-brand"><img src="/diyafti-logo.jpeg" alt="شعار لارت"/><div><small>لارت للضيافة</small><h1>فاتورة ضيافة</h1><span>فاتورة متابعة للطلب</span></div></div>
            <div className="invoice-number"><span>رقم الفاتورة</span><strong>{invoiceNumber(invoiceBooking)}</strong><small>تاريخ الإصدار: {fmtDate(invoiceBooking.orderDate || invoiceBooking.eventDate)}</small><small>الحالة: {invoiceBooking.status}</small></div>
          </header>
          <section className="invoice-customer"><div><span>فاتورة إلى</span><strong>{invoiceBooking.customerName || "عميل"}</strong></div><div><span>رقم الجوال</span><strong>{invoiceBooking.customerPhone || "—"}</strong></div><div><span>موعد التنفيذ</span><strong>{fmtDate(invoiceBooking.eventDate)}{invoiceBooking.eventTime ? ` · ${invoiceBooking.eventTime}` : ""}</strong></div></section>
          <table className="invoice-table"><thead><tr><th>م</th><th>البيان</th><th>العدد</th><th>المبلغ</th></tr></thead><tbody><tr><td>١</td><td>{invoiceBooking.eventType}{invoiceBooking.notes ? <small>{invoiceBooking.notes}</small> : null}</td><td>{invoiceBooking.guestCount} شخص</td><td>{formatSAR(bookingTotalCents(invoiceBooking))}</td></tr></tbody></table>
          <section className="invoice-totals"><div><span>المبلغ الإجمالي</span><strong>{formatSAR(bookingTotalCents(invoiceBooking))}</strong></div><div><span>المبلغ المدفوع</span><strong>{formatSAR(moneyCents(invoiceBooking.paidAmount))}</strong></div><div className="invoice-balance"><span>المبلغ المتبقي</span><strong>{formatSAR(bookingTotalCents(invoiceBooking) - moneyCents(invoiceBooking.paidAmount))}</strong></div></section>
          <footer className="invoice-footer"><p className="invoice-thanks">شكرًا لاختياركم لارت لضيافتكم، ونسعد بخدمتكم دائمًا.</p><div className="invoice-footer-brand">لارت <span>·</span> ضيافتكم على ذوقكم</div><p className="invoice-disclaimer">فاتورة متابعة غير ضريبية؛ لا تتضمن ضريبة القيمة المضافة أو رقمًا ضريبيًا.</p></footer>
        </article></section></div>}
  </div>;
}
