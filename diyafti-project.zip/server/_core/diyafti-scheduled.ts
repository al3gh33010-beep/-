import type { Request, Response } from "express";
import { and, asc, eq, gte, isNotNull, isNull, lte, ne } from "drizzle-orm";
import { bookings, emailSettings } from "../../drizzle/schema";
import { getDb } from "../db";
import { sdk } from "./sdk";
import { getGmailSenderEmail, hasGmailAppPassword, mailErrorCode, sendBookingReminder, sendNewBookingEmail, sendWeeklyBackup, validEmailAddress } from "./mailer";

function riyadhDate(now = new Date()) {
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Riyadh", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(now);
  const get = (type: string) => parts.find(part => part.type === type)?.value ?? "";
  return `${get("year")}-${get("month")}-${get("day")}`;
}

function plusDays(date: string, days: number) {
  const result = new Date(`${date}T12:00:00Z`);
  result.setUTCDate(result.getUTCDate() + days);
  return result.toISOString().slice(0, 10);
}

function isRiyadhSunday(now = new Date()) {
  return new Intl.DateTimeFormat("en-US", { timeZone: "Asia/Riyadh", weekday: "short" }).format(now) === "Sun";
}

export async function scheduledGmailHandler(req: Request, res: Response) {
  let identity;
  try { identity = await sdk.authenticateRequest(req); }
  catch { return res.status(401).json({ error: "رفض التحقق من هوية المهمة المجدولة." }); }
  if (!identity.isCron || !identity.taskUid) return res.status(403).json({ error: "هذا المسار مخصص للمهمة المجدولة فقط." });

  try {
    const db = await getDb();
    if (!db) throw new Error("database unavailable");
    const [settings] = await db.select().from(emailSettings).limit(1);
    if (!settings?.automationEnabled || !settings.scheduleTaskUid || settings.scheduleTaskUid !== identity.taskUid)
      return res.status(200).json({ skipped: true });
    const senderEmail = getGmailSenderEmail();
    if (!validEmailAddress(senderEmail) || !validEmailAddress(settings.recipientEmail) || !hasGmailAppPassword())
      return res.status(503).json({ error: "إعداد بريد Gmail غير مكتمل." });
    const mailSettings = { senderEmail, recipientEmail: settings.recipientEmail };

    const today = riyadhDate();
    const throughDate = plusDays(today, 7);
    let bookingEmailsSent = 0;
    let remindersSent = 0;
    let failures = 0;
    const pendingBookingEmails = await db.select().from(bookings).where(isNull(bookings.createdEmailSentAt)).orderBy(asc(bookings.createdAt)).limit(100);
    for (const booking of pendingBookingEmails) {
      try {
        await sendNewBookingEmail(mailSettings, booking);
        const sentAt = new Date();
        const isDue = booking.eventDate >= today && booking.eventDate <= throughDate && booking.status !== "مكتملة" && booking.status !== "ملغاة";
        await db.update(bookings).set({ createdEmailSentAt: sentAt, ...(isDue ? { reminderSentAt: sentAt } : {}) }).where(eq(bookings.uid, booking.uid));
        bookingEmailsSent += 1;
      } catch (error) {
        failures += 1;
        console.warn("Pending new-booking email failed", mailErrorCode(error));
      }
    }
    const due = await db.select().from(bookings).where(and(
      gte(bookings.eventDate, today),
      lte(bookings.eventDate, throughDate),
      isNull(bookings.reminderSentAt),
      isNotNull(bookings.createdEmailSentAt),
      ne(bookings.status, "مكتملة"),
      ne(bookings.status, "ملغاة"),
    )).orderBy(asc(bookings.eventDate), asc(bookings.eventTime));
    for (const booking of due) {
      try {
        await sendBookingReminder(mailSettings, booking);
        await db.update(bookings).set({ reminderSentAt: new Date() }).where(eq(bookings.uid, booking.uid));
        remindersSent += 1;
      } catch (error) {
        failures += 1;
        console.warn("Scheduled Gmail reminder failed", mailErrorCode(error));
      }
    }

    let weeklyBackupSent = false;
    if (isRiyadhSunday() && settings.lastWeeklyBackupDate !== today) {
      try {
        const allBookings = await db.select().from(bookings).orderBy(asc(bookings.eventDate), asc(bookings.eventTime));
        await sendWeeklyBackup(mailSettings, allBookings, today, throughDate);
        await db.update(emailSettings).set({ lastWeeklyBackupDate: today }).where(eq(emailSettings.id, 1));
        weeklyBackupSent = true;
      } catch (error) {
        failures += 1;
        console.warn("Scheduled Gmail backup failed", mailErrorCode(error));
      }
    }

    if (failures) return res.status(503).json({ bookingEmailsSent, remindersSent, weeklyBackupSent, failures });
    return res.json({ bookingEmailsSent, remindersSent, weeklyBackupSent });
  } catch (error) {
    console.error("Scheduled Gmail callback failed", mailErrorCode(error));
    return res.status(503).json({ error: "تعذر إكمال الإرسال المجدول." });
  }
}
