import nodemailer from "nodemailer";
import type { Booking } from "../../drizzle/schema";

export type MailSettings = { senderEmail: string; recipientEmail: string };

export function validEmailAddress(value: unknown): value is string {
  return typeof value === "string"
    && value.length <= 320
    && /^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(value.trim())
    && !/[\r\n]/.test(value);
}

export function hasGmailAppPassword() {
  return Boolean(process.env.DIYAFITI_GMAIL_APP_PASSWORD?.replace(/\s/g, ""));
}

export function getGmailSenderEmail() {
  const senderEmail = process.env.DIYAFITI_GMAIL_SENDER_EMAIL?.trim() ?? "";
  return validEmailAddress(senderEmail) ? senderEmail : "";
}

function mailer(senderEmail: string) {
  const appPassword = process.env.DIYAFITI_GMAIL_APP_PASSWORD?.replace(/\s/g, "");
  if (!appPassword) throw new Error("GMAIL_APP_PASSWORD_MISSING");
  if (!validEmailAddress(senderEmail)) throw new Error("GMAIL_SENDER_INVALID");
  return nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 465,
    secure: true,
    auth: { user: senderEmail.trim(), pass: appPassword },
    connectionTimeout: 15_000,
    greetingTimeout: 15_000,
    socketTimeout: 30_000,
  });
}

function safeSubject(value: string) {
  return value.replace(/[\r\n]+/g, " ").slice(0, 180);
}

function sar(value: string | number) {
  const amount = Number(value);
  if (!Number.isFinite(amount)) return "—";
  return new Intl.NumberFormat("ar-SA", { style: "currency", currency: "SAR", minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(amount);
}

export async function sendTestEmail(settings: MailSettings) {
  await mailer(settings.senderEmail).sendMail({
    from: { name: "ضيافتي", address: settings.senderEmail.trim() },
    to: settings.recipientEmail.trim(),
    subject: "رسالة اختبار ربط Gmail - ضيافتي",
    text: "تم إرسال هذه الرسالة للتأكد من إعداد Gmail لاستقبال تنبيهات ضيافتي.",
  });
}

export async function sendNewBookingEmail(settings: MailSettings, booking: Booking) {
  const total = Number(booking.totalAmount || 0);
  const paid = Number(booking.paidAmount || 0);
  const remaining = Math.max(0, total - paid);
  const details = [
    "تمت إضافة ضيافة جديدة إلى نظام ضيافتي:",
    `الصنف: ${booking.eventType}`,
    `تاريخ تسجيل الطلب: ${booking.orderDate || "غير محدد"}`,
    `تاريخ العمل: ${booking.eventDate}${booking.eventTime ? `، الوقت: ${booking.eventTime}` : ""}`,
    `العميل: ${booking.customerName || "غير محدد"}`,
    `رقم الجوال: ${booking.customerPhone || "غير محدد"}`,
    `عدد الأشخاص: ${booking.guestCount}`,
    `الإجمالي: ${sar(booking.totalAmount)}`,
    `المدفوع: ${sar(booking.paidAmount)}`,
    `المتبقي: ${sar(remaining)}`,
    `الحالة: ${booking.status}`,
    booking.notes ? `ملاحظات: ${booking.notes}` : "ملاحظات: لا توجد",
  ].join("\n");
  await mailer(settings.senderEmail).sendMail({
    from: { name: "لارت | ضيافتي", address: settings.senderEmail.trim() },
    to: settings.recipientEmail.trim(),
    subject: safeSubject(`ضيافة جديدة: ${booking.eventType} - ${booking.eventDate}`),
    text: details,
  });
}

export async function sendBookingReminder(settings: MailSettings, booking: Booking) {
  const total = Number(booking.totalAmount || 0);
  const paid = Number(booking.paidAmount || 0);
  const remaining = Math.max(0, total - paid);
  const details = [
    "تذكير بموعد ضيافة قريب:",
    `الصنف: ${booking.eventType}`,
    `التاريخ: ${booking.eventDate}${booking.eventTime ? `، الوقت: ${booking.eventTime}` : ""}`,
    `العميل: ${booking.customerName || "غير محدد"}`,
    `الجوال: ${booking.customerPhone || "غير محدد"}`,
    `عدد الأشخاص: ${booking.guestCount}`,
    `الإجمالي: ${sar(booking.totalAmount)}`,
    `المدفوع: ${sar(booking.paidAmount)}`,
    `المتبقي: ${sar(remaining)}`,
    booking.notes ? `ملاحظات: ${booking.notes}` : "",
  ].filter(Boolean).join("\n");
  await mailer(settings.senderEmail).sendMail({
    from: { name: "ضيافتي", address: settings.senderEmail.trim() },
    to: settings.recipientEmail.trim(),
    subject: safeSubject(`تذكير ضيافتي: ${booking.eventType} - ${booking.eventDate}`),
    text: details,
  });
}

function backupBooking(booking: Booking) {
  const { unitPrice: _legacyUnitPrice, customerEmail: _unusedEmail, reminderSentAt: _internalReminderState, createdEmailSentAt: _internalCreatedEmailState, ...safe } = booking;
  return safe;
}

export async function sendWeeklyBackup(settings: MailSettings, bookings: Booking[], today: string, throughDate: string) {
  const upcoming = bookings.filter(booking => booking.eventDate >= today && booking.eventDate <= throughDate && booking.status !== "مكتملة" && booking.status !== "ملغاة");
  const lines = upcoming.map(booking => `• ${booking.eventDate}${booking.eventTime ? ` ${booking.eventTime}` : ""} — ${booking.eventType} — ${booking.customerName || "بدون اسم"} — ${booking.guestCount} شخص`);
  const exportedAt = new Date().toISOString();
  const backup = { app: "ضيافتي", version: 1, exportedAt, bookings: bookings.map(backupBooking) };
  await mailer(settings.senderEmail).sendMail({
    from: { name: "ضيافتي", address: settings.senderEmail.trim() },
    to: settings.recipientEmail.trim(),
    subject: `خطة ضيافتي والنسخة الأسبوعية - ${today}`,
    text: [
      `ملخص المواعيد القادمة حتى ${throughDate}:`,
      ...(lines.length ? lines : ["لا توجد ضيافات مجدولة خلال الأيام السبعة القادمة."]),
      "",
      `إجمالي السجلات في النسخة الاحتياطية المرفقة: ${bookings.length}`,
      "أرفقنا ملف JSON بجميع الضيافات المحفوظة لتتمكن من الاحتفاظ بنسخة واستعادتها عند الحاجة.",
    ].join("\n"),
    attachments: [{
      filename: `diyafti-backup-${today}.json`,
      content: JSON.stringify(backup, null, 2),
      contentType: "application/json; charset=utf-8",
    }],
  });
}

export function mailErrorCode(error: unknown) {
  if (error && typeof error === "object" && "code" in error && typeof error.code === "string") return error.code.slice(0, 64);
  if (error instanceof Error && ["GMAIL_APP_PASSWORD_MISSING", "GMAIL_SENDER_INVALID"].includes(error.message)) return error.message;
  return "EMAIL_DELIVERY_FAILED";
}
