import { createHmac, randomUUID, timingSafeEqual } from "node:crypto";
import express, { type Request, type Response, type NextFunction } from "express";
import { and, asc, eq, gte, isNull, lte, ne } from "drizzle-orm";
import { bookings, emailSettings, type Booking } from "../../drizzle/schema";
import { getDb } from "../db";
import { createHeartbeatJob, listHeartbeatJobs, updateHeartbeatJob } from "./heartbeat";
import { getGmailSenderEmail, hasGmailAppPassword, mailErrorCode, sendBookingReminder, sendNewBookingEmail, sendTestEmail, validEmailAddress } from "./mailer";

const router = express.Router();
const SESSION_COOKIE = "diyafati_session";
const SESSION_AGE = 7 * 24 * 60 * 60;
const failures = new Map<string, { count: number; since: number; blockedUntil: number }>();
const allowedStatuses = new Set(["مؤكدة", "قيد التجهيز", "مكتملة", "ملغاة"]);
function riyadhToday() {
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Riyadh", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(new Date());
  const get = (type: string) => parts.find(part => part.type === type)?.value ?? "";
  return `${get("year")}-${get("month")}-${get("day")}`;
}
function moneyCents(value: unknown): number | null {
  if (value === undefined || value === "") return 0;
  if (typeof value !== "string" && typeof value !== "number") return null;
  const text = String(value);
  if (!/^\d{1,9}(?:\.\d{1,2})?$/.test(text)) return null;
  const cents = Math.round((Number(text) + Number.EPSILON) * 100);
  return Number.isSafeInteger(cents) && cents <= 10_000_000_000 ? cents : null;
}
function moneyStored(value: unknown) {
  const cents = moneyCents(value) ?? 0;
  return `${Math.floor(cents / 100)}.${String(cents % 100).padStart(2, "0")}`;
}
function datePlusDays(date: string, days: number) {
  const result = new Date(`${date}T12:00:00Z`);
  result.setUTCDate(result.getUTCDate() + days);
  return result.toISOString().slice(0, 10);
}
function needsReminder(booking: Booking) {
  const today = riyadhToday();
  return booking.eventDate >= today && booking.eventDate <= datePlusDays(today, 7)
    && booking.status !== "مكتملة" && booking.status !== "ملغاة";
}
async function tryImmediateReminder(db: NonNullable<Awaited<ReturnType<typeof getDb>>>, booking: Booking) {
  if (!needsReminder(booking)) return { reminderDue: false, reminderSent: false };
  const [settings] = await db.select().from(emailSettings).limit(1);
  const senderEmail = getGmailSenderEmail();
  if (!settings?.automationEnabled || !hasGmailAppPassword() || !senderEmail || !settings.recipientEmail)
    return { reminderDue: true, reminderSent: false };
  try {
    await sendBookingReminder({ senderEmail, recipientEmail: settings.recipientEmail }, booking);
    await db.update(bookings).set({ reminderSentAt: new Date() }).where(eq(bookings.uid, booking.uid));
    return { reminderDue: true, reminderSent: true };
  } catch (error) {
    console.warn("Immediate Gmail reminder failed", mailErrorCode(error));
    return { reminderDue: true, reminderSent: false };
  }
}
async function tryNewBookingEmail(db: NonNullable<Awaited<ReturnType<typeof getDb>>>, booking: Booking) {
  const [settings] = await db.select().from(emailSettings).limit(1);
  const senderEmail = getGmailSenderEmail();
  if (!settings?.recipientEmail || !senderEmail || !hasGmailAppPassword()) return false;
  try {
    await sendNewBookingEmail({ senderEmail, recipientEmail: settings.recipientEmail }, booking);
    const sentAt = new Date();
    await db.update(bookings).set({ createdEmailSentAt: sentAt, ...(needsReminder(booking) ? { reminderSentAt: sentAt } : {}) }).where(eq(bookings.uid, booking.uid));
    return true;
  } catch (error) {
    console.warn("New booking Gmail email failed", mailErrorCode(error));
    return false;
  }
}

type BookingInput = { orderDate?: string; eventDate: string; eventTime?: string; eventType: string; guestCount: number; totalAmount?: string | number; unitPrice?: string | number; paidAmount?: string | number; customerName?: string; customerPhone?: string; notes?: string; status?: string; uid?: string };
function getPassword() {
  const secret = process.env.DIYAFATI_LOGIN_PASSWORD;
  if (!secret) throw new Error("Login password is not configured");
  return secret;
}
function signature(payload: string) {
  return createHmac("sha256", getPassword()).update(payload).digest("base64url");
}
function safeEqual(a: string, b: string) {
  const aa = createHmac("sha256", "diyafti-constant-time").update(a).digest();
  const bb = createHmac("sha256", "diyafti-constant-time").update(b).digest();
  return timingSafeEqual(aa, bb);
}
function issueSession() {
  const payload = Buffer.from(JSON.stringify({ username: "Lart_1100", exp: Math.floor(Date.now() / 1000) + SESSION_AGE })).toString("base64url");
  return `${payload}.${signature(payload)}`;
}
function validSessionToken(raw: string) {
  const [payload, sig, extra] = raw.split(".");
  if (!payload || !sig || extra) return false;
  try {
    if (!safeEqual(sig, signature(payload))) return false;
    const data = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
    return data.username === "Lart_1100" && Number(data.exp) > Date.now() / 1000;
  } catch { return false; }
}
function isSessionValid(req: Request) {
  const cookie = req.headers.cookie?.split(";").map(s => s.trim()).find(s => s.startsWith(`${SESSION_COOKIE}=`))?.slice(SESSION_COOKIE.length + 1);
  const bearer = req.get("authorization")?.match(/^Bearer ([A-Za-z0-9._-]+)$/i)?.[1];
  return [cookie, bearer].some(token => typeof token === "string" && validSessionToken(token));
}
function setSession(res: Response, token: string) {
  res.cookie(SESSION_COOKIE, token, { httpOnly: true, secure: true, sameSite: "none", path: "/", maxAge: SESSION_AGE * 1000 });
}
function clearSession(res: Response) {
  res.clearCookie(SESSION_COOKIE, { httpOnly: true, secure: true, sameSite: "none", path: "/" });
}
function requireLogin(req: Request, res: Response, next: NextFunction) {
  if (!isSessionValid(req)) return res.status(401).json({ error: "انتهت الجلسة، سجّل الدخول مرة أخرى." });
  next();
}
function requireSameOriginForChanges(req: Request, res: Response, next: NextFunction) {
  if (["GET", "HEAD", "OPTIONS"].includes(req.method)) return next();
  const fetchSite = req.get("sec-fetch-site");
  if (fetchSite) return ["same-origin", "none"].includes(fetchSite) ? next() : res.status(403).json({ error: "تم رفض الطلب لأسباب أمنية." });
  const origin = req.get("origin");
  if (!origin) return next();
  const forwardedHost = req.get("x-forwarded-host")?.split(",")[0].trim();
  const host = forwardedHost || req.get("host");
  try { return new URL(origin).host === host ? next() : res.status(403).json({ error: "تم رفض الطلب لأسباب أمنية." }); }
  catch { return res.status(403).json({ error: "تم رفض الطلب لأسباب أمنية." }); }
}
export function validInput(value: unknown): value is BookingInput {
  if (!value || typeof value !== "object") return false;
  const b = value as Record<string, unknown>;
  const totalAmountCents = moneyCents(b.totalAmount ?? b.unitPrice);
  const paidAmountCents = moneyCents(b.paidAmount);
  return typeof b.eventDate === "string" && /^\d{4}-\d{2}-\d{2}$/.test(b.eventDate)
    && (b.orderDate === undefined || (typeof b.orderDate === "string" && /^\d{4}-\d{2}-\d{2}$/.test(b.orderDate)))
    && typeof b.eventType === "string" && b.eventType.trim().length > 0 && b.eventType.length <= 120
    && Number.isInteger(b.guestCount) && Number(b.guestCount) >= 1 && Number(b.guestCount) <= 100000
    && totalAmountCents !== null && paidAmountCents !== null && paidAmountCents <= totalAmountCents
    && (b.eventTime === undefined || b.eventTime === "" || (typeof b.eventTime === "string" && /^([01]\d|2[0-3]):[0-5]\d$/.test(b.eventTime)))
    && (b.customerName === undefined || (typeof b.customerName === "string" && b.customerName.length <= 160))
    && (b.customerPhone === undefined || (typeof b.customerPhone === "string" && b.customerPhone.length <= 32 && (b.customerPhone === "" || /^[+\d()\s-]{7,32}$/.test(b.customerPhone))))
    && (b.notes === undefined || (typeof b.notes === "string" && b.notes.length <= 5000))
    && (b.status === undefined || (typeof b.status === "string" && allowedStatuses.has(b.status)));
}
router.get("/me", (req, res) => res.json({ authenticated: isSessionValid(req), username: isSessionValid(req) ? "Lart_1100" : null }));
router.post("/login", (req, res) => {
  const ip = req.ip || "unknown";
  const now = Date.now();
  const state = failures.get(ip) ?? { count: 0, since: now, blockedUntil: 0 };
  if (now < state.blockedUntil) return res.status(429).json({ error: "محاولات كثيرة. انتظر 15 دقيقة ثم حاول مجددًا." });
  if (now - state.since > 15 * 60 * 1000) { state.count = 0; state.since = now; state.blockedUntil = 0; }
  const username = typeof req.body?.username === "string" ? req.body.username : "";
  const password = typeof req.body?.password === "string" ? req.body.password : "";
  let passwordOK = false;
  try { passwordOK = safeEqual(password, getPassword()); } catch { return res.status(503).json({ error: "تسجيل الدخول غير مهيأ بعد." }); }
  if (!safeEqual(username, "Lart_1100") || !passwordOK) {
    state.count += 1;
    if (state.count >= 5) state.blockedUntil = now + 15 * 60 * 1000;
    failures.set(ip, state);
    return res.status(state.blockedUntil ? 429 : 401).json({ error: "اسم المستخدم أو كلمة المرور غير صحيحة." });
  }
  failures.delete(ip);
  const token = issueSession();
  setSession(res, token);
  return res.json({ authenticated: true, token });
});
router.post("/logout", requireSameOriginForChanges, (_req, res) => { clearSession(res); res.json({ ok: true }); });
router.use(requireLogin);
router.use(requireSameOriginForChanges);
router.get("/email-settings", async (_req, res) => {
  try {
    const db = await getDb(); if (!db) throw new Error("database unavailable");
    const [settings] = await db.select().from(emailSettings).limit(1);
    res.json({ recipientEmail: settings?.recipientEmail ?? "", senderEmailConfigured: Boolean(getGmailSenderEmail()), appPasswordConfigured: hasGmailAppPassword(), automationEnabled: Boolean(settings?.automationEnabled), canSchedule: process.env.NODE_ENV === "production" });
  } catch (error) { console.error("Email settings read failed", mailErrorCode(error)); res.status(503).json({ error: "تعذر تحميل إعدادات Gmail." }); }
});
router.put("/email-settings", async (req, res) => {
  const recipientEmail = typeof req.body?.recipientEmail === "string" ? req.body.recipientEmail.trim() : "";
  if (!validEmailAddress(recipientEmail)) return res.status(400).json({ error: "اكتب بريدًا صالحًا لاستقبال التنبيهات." });
  try {
    const db = await getDb(); if (!db) throw new Error("database unavailable");
    await db.insert(emailSettings).values({ id: 1, recipientEmail }).onDuplicateKeyUpdate({ set: { recipientEmail } });
    const [settings] = await db.select().from(emailSettings).limit(1);
    res.json({ recipientEmail: settings?.recipientEmail ?? recipientEmail, senderEmailConfigured: Boolean(getGmailSenderEmail()), appPasswordConfigured: hasGmailAppPassword(), automationEnabled: Boolean(settings?.automationEnabled), canSchedule: process.env.NODE_ENV === "production" });
  } catch (error) { console.error("Email settings save failed", mailErrorCode(error)); res.status(503).json({ error: "تعذر حفظ بريد التنبيهات." }); }
});
router.post("/email-settings/test", async (_req, res) => {
  try {
    const db = await getDb(); if (!db) throw new Error("database unavailable");
    const [settings] = await db.select().from(emailSettings).limit(1);
    if (!settings?.recipientEmail) return res.status(400).json({ error: "احفظ بريد استلام التنبيهات أولًا." });
    const senderEmail = getGmailSenderEmail();
    if (!senderEmail || !hasGmailAppPassword()) return res.status(409).json({ error: "إعداد حساب Gmail المرسل غير مكتمل." });
    await sendTestEmail({ senderEmail, recipientEmail: settings.recipientEmail });
    res.json({ ok: true });
  } catch (error) { console.error("Gmail test send failed", mailErrorCode(error)); res.status(503).json({ error: "تعذر إرسال رسالة الاختبار. تحقق من إعداد Gmail وعنوان الاستقبال." }); }
});
router.post("/email-settings/automation", async (req, res) => {
  const enabled = req.body?.enabled;
  if (typeof enabled !== "boolean") return res.status(400).json({ error: "إعداد التفعيل غير صالح." });
  try {
    const db = await getDb(); if (!db) throw new Error("database unavailable");
    const [settings] = await db.select().from(emailSettings).limit(1);
    const jobName = "diyafti-gmail-reminders";
    const existing = await listHeartbeatJobs("", { page: 1, pageSize: 200 });
    const matchingJob = existing.jobs.find(job => job.name === jobName);
    if (!enabled) {
      if (matchingJob?.isEnable) await updateHeartbeatJob(matchingJob.taskUid, { enable: false }, "");
      await db.insert(emailSettings).values({ id: 1, automationEnabled: 0, scheduleTaskUid: matchingJob?.taskUid ?? "" }).onDuplicateKeyUpdate({ set: { automationEnabled: 0, scheduleTaskUid: matchingJob?.taskUid ?? "" } });
      return res.json({ automationEnabled: false });
    }
    if (process.env.NODE_ENV !== "production") return res.status(409).json({ error: "انشر الموقع أولًا؛ المهام المجدولة تستدعي النسخة المنشورة فقط." });
    if (!settings?.recipientEmail) return res.status(400).json({ error: "احفظ بريد استلام التنبيهات أولًا." });
    if (!getGmailSenderEmail() || !hasGmailAppPassword()) return res.status(409).json({ error: "إعداد حساب Gmail المرسل غير مكتمل." });
    let taskUid = matchingJob?.taskUid ?? "";
    if (taskUid) {
      await updateHeartbeatJob(taskUid, { cron: "0 0 6 * * *", path: "/api/scheduled/email", method: "POST", description: "تذكيرات ضيافتي اليومية والنسخة الأسبوعية الساعة 9 صباحًا بتوقيت الرياض", enable: true }, "");
    } else {
      const created = await createHeartbeatJob({ name: jobName, cron: "0 0 6 * * *", path: "/api/scheduled/email", method: "POST", description: "تذكيرات ضيافتي اليومية والنسخة الأسبوعية الساعة 9 صباحًا بتوقيت الرياض" }, "");
      taskUid = created.taskUid;
    }
    await db.insert(emailSettings).values({ id: 1, recipientEmail: settings.recipientEmail, scheduleTaskUid: taskUid, automationEnabled: 1 }).onDuplicateKeyUpdate({ set: { scheduleTaskUid: taskUid, automationEnabled: 1 } });
    res.json({ automationEnabled: true });
  } catch (error) { console.error("Gmail schedule update failed", mailErrorCode(error)); res.status(503).json({ error: "تعذر تفعيل الجدولة. تحقق من إعدادات Gmail ونشر الموقع." }); }
});
router.get("/bookings", async (_req, res) => {
  try { const db = await getDb(); if (!db) throw new Error("database unavailable");
    const rows = await db.select().from(bookings).orderBy(asc(bookings.eventDate), asc(bookings.eventTime));
    res.json(rows.map(({ customerEmail: _email, unitPrice: _legacyUnitPrice, reminderSentAt: _internalReminderState, createdEmailSentAt: _internalCreatedEmailState, ...booking }) => booking));
  } catch (error) { console.error("Bookings read failed", error); res.status(503).json({ error: "تعذر تحميل الضيافات. تحقق من اتصال قاعدة البيانات." }); }
});
router.post("/bookings", async (req, res) => {
  if (!validInput(req.body)) return res.status(400).json({ error: "راجع بيانات الضيافة المدخلة." });
  try { const db = await getDb(); if (!db) throw new Error("database unavailable");
    const b = req.body as BookingInput;
    const uid = randomUUID();
    await db.insert(bookings).values({ uid, orderDate: b.orderDate ?? riyadhToday(), eventDate: b.eventDate, eventTime: b.eventTime ?? "", eventType: b.eventType.trim(), guestCount: b.guestCount, unitPrice: "0.00", totalAmount: moneyStored(b.totalAmount ?? b.unitPrice), paidAmount: moneyStored(b.paidAmount), customerName: b.customerName?.trim() ?? "", customerPhone: b.customerPhone?.trim() ?? "", notes: b.notes?.trim() ?? "", status: (b.status ?? "مؤكدة") as Booking["status"] });
    const [created] = await db.select().from(bookings).where(eq(bookings.uid, uid)).limit(1);
    const createdEmailSent = created ? await tryNewBookingEmail(db, created) : false;
    res.status(201).json({ uid, createdEmailSent });
  } catch (error) { console.error("Booking create failed", error); res.status(503).json({ error: "تعذر حفظ الضيافة." }); }
});
router.put("/bookings/:uid", async (req, res) => {
  if (!validInput(req.body)) return res.status(400).json({ error: "راجع بيانات الضيافة المدخلة." });
  try { const db = await getDb(); if (!db) throw new Error("database unavailable");
    const b = req.body as BookingInput;
    const [previous] = await db.select().from(bookings).where(eq(bookings.uid, req.params.uid)).limit(1);
    if (!previous) return res.status(404).json({ error: "الضيافة غير موجودة." });
    const dateChanged = previous.eventDate !== b.eventDate;
    await db.update(bookings).set({ eventDate: b.eventDate, eventTime: b.eventTime ?? "", eventType: b.eventType.trim(), guestCount: b.guestCount, totalAmount: moneyStored(b.totalAmount ?? b.unitPrice), paidAmount: moneyStored(b.paidAmount), customerName: b.customerName?.trim() ?? "", customerPhone: b.customerPhone?.trim() ?? "", notes: b.notes?.trim() ?? "", status: (b.status ?? "مؤكدة") as Booking["status"], ...(dateChanged ? { reminderSentAt: null } : {}) }).where(eq(bookings.uid, req.params.uid));
    const [updated] = await db.select().from(bookings).where(eq(bookings.uid, req.params.uid)).limit(1);
    const reminder = dateChanged && updated ? await tryImmediateReminder(db, updated) : { reminderDue: false, reminderSent: false };
    res.json({ ok: true, ...reminder });
  } catch (error) { console.error("Booking update failed", error); res.status(503).json({ error: "تعذر تحديث الضيافة." }); }
});
router.delete("/bookings/:uid", async (req, res) => {
  try { const db = await getDb(); if (!db) throw new Error("database unavailable");
    await db.delete(bookings).where(eq(bookings.uid, req.params.uid)); res.json({ ok: true });
  } catch (error) { console.error("Booking delete failed", error); res.status(503).json({ error: "تعذر حذف الضيافة." }); }
});
router.post("/bookings/import", async (req, res) => {
  const items = req.body?.bookings;
  if (!Array.isArray(items) || items.length > 5000 || !items.every(validInput)) return res.status(400).json({ error: "ملف النسخة غير صالح أو يتجاوز الحد المسموح." });
  try { const db = await getDb(); if (!db) throw new Error("database unavailable");
    for (const item of items as BookingInput[]) {
      const uid = typeof item.uid === "string" && /^[\w-]{20,36}$/.test(item.uid) ? item.uid : randomUUID();
      const values = { uid, orderDate: item.orderDate ?? new Date().toISOString().slice(0, 10), eventDate: item.eventDate, eventTime: item.eventTime ?? "", eventType: item.eventType.trim(), guestCount: item.guestCount, unitPrice: moneyStored(item.unitPrice), totalAmount: moneyStored(item.totalAmount ?? item.unitPrice), paidAmount: moneyStored(item.paidAmount), customerName: item.customerName?.trim() ?? "", customerPhone: item.customerPhone?.trim() ?? "", notes: item.notes?.trim() ?? "", status: (item.status ?? "مؤكدة") as Booking["status"], createdEmailSentAt: new Date() };
      await db.insert(bookings).values(values).onDuplicateKeyUpdate({ set: { orderDate: values.orderDate, eventDate: values.eventDate, eventTime: values.eventTime, eventType: values.eventType, guestCount: values.guestCount, totalAmount: values.totalAmount, paidAmount: values.paidAmount, customerName: values.customerName, customerPhone: values.customerPhone, notes: values.notes, status: values.status } });
    }
    res.json({ ok: true, imported: items.length });
  } catch (error) { console.error("Backup restore failed", error); res.status(503).json({ error: "تعذرت استعادة النسخة." }); }
});
export const diyaftiRouter = router;
